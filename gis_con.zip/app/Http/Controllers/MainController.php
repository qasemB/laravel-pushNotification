<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;

class MainController extends Controller
{
    public function index()
    {
        return view('welcome');
    }
    public function store(Request $request)
    {
        $request->validate([
            "phone_number" => "required|numeric|unique:students,phone_number|digits:11",
            "level" => "required|numeric|max:4"
        ],[
            'phone_number.required' => 'شماره تماس رو لطفا  پر کن',
            'phone_number.numeric' => 'شماره تماس فقط میتواند عدد باشد',
            'phone_number.unique' => 'این شماره تماس قبلا ثبت شده',
            'phone_number.digits' => 'شماره تماس باید 11 رقم باشه',
            'level.required' => 'سطح اطلاعاتت رو لطفا مشخص کن',
        ]);
        $post = new Student;
        $post->phone_number = $request->phone_number;
        $post->level = $request->level;
        $post->save();
        return redirect('home')->with('status', 'اطلاعات شما با موفقیت ثبت شد');
    }
}
