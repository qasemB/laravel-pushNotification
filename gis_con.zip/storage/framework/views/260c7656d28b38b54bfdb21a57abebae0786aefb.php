<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/bootstrap5/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="/assets/fontawesome6/css/all.min.css">
    <title>گروه GIS آبفا مرکزی</title>
</head>
<style>
    @font-face {
        font-family: iran;
        src: url("/assets/fonts/iran-sans-400.eot") format("eot"),
            url("/assets/fonts/iran-sans-400.woff") format("woff"),
            url("/assets/fonts/iran-sans-400.ttf") format("truetype");
        /* font-weight: bold; */
    }

    * {
        direction: rtl;
        text-align: right;
        font-family: "iran"
    }

    body {
        width: 100%;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background: url(/assets/images/sideBack3.jpg) no-repeat;
        padding: 10px;
        background-position: center;
        background-size: cover;
    }

    #register_form_box {
        background: #ffffffd1;
        border-radius: 11px;
    }

    #success_alert,
    #error_alert {
        position: fixed;
        width: 100%;
        bottom: -15px;
        transition: all 300ms ease
    }

    #success_alert.hide {
        bottom: -200px
    }

    #bio_link {
        position: fixed;
        bottom: 5px;
        right: 5px;
        border-radius: 100%;
        display: block;
        width: 60px;
        height: 60px;
        overflow: hidden;
    }
</style>

<body dir="rtl">

    <?php if(session('status')): ?>
        <div class="alert alert-success" id="success_alert">
            <?php echo e(session('status')); ?>

        </div>
        <script>
            setTimeout(() => document.getElementById("success_alert").classList.add("hide"), 5000);
        </script>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger" id="error_alert">
            <ul class="m-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div id="register_form_box" class="p-3">

        <div class="text-center mb-3">
            <i class="fa-solid fa-chalkboard-user fa-4x"></i>
        </div>

        <small class="text-center d-block text-primary mb-3">
            اگر علاقمند به یادگیری برنامه نویسی و طراحی در زمینه WebGis هستید، شماره تماستون رو به ما امانت بدید تا در
            صورت به حد نصاب رسیدن تقاضا، باهاتون هماهنگ بشیم
        </small>
        <a target="_blank" href="https://codeyad.com/Masters/Profile/qasemb" id="bio_link">
            <img src="/assets/images/avatar.jpg" alt="قاسم بساکی" class="w-100 h-100">
        </a>

        <form id="register_form" name="register_form" method="POST" action="<?php echo e(url('store-form')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="phone_number" class="form-label">شماره تماس</label>
                <input name="phone_number" type="number" class="form-control" id="phone_number"
                    placeholder="فقط عدد وارد کنید">
                
            </div>

            <div class="mb-3">
                <select class="form-select" id="need_item" name="level">
                    <option value="" selected>چقدر از برنامه نویسی وب میدونی؟</option>
                    <option value="1">هیچی نمیدونم</option>
                    <option value="2">یه چیزایی از HTML,CSS بلدم</option>
                    <option value="3">HTML,CSS,JS بلدم ولی پروژه نزدم</option>
                    <option value="4">HTML,CSS,JS,... بلدم و پروژه هم میتونم بزنم</option>
                </select>
                <div class="form-text"></div>
            </div>

            

            
            
            

            <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary w-50">ثبت</button>
            </div>
        </form>
    </div>

    <script src="/assets/bootstrap5/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH D:\00programming\projects\gis_cofrance\gis_con\resources\views/welcome.blade.php ENDPATH**/ ?>